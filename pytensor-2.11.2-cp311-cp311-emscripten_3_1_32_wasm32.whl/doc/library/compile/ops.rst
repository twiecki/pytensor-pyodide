==================================================
:mod:`ops` --  Some Common Ops and extra Ops stuff
==================================================

.. automodule:: pytensor.compile.ops
    :members:
