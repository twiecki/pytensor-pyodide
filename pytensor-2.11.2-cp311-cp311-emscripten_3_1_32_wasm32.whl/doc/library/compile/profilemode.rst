:orphan:

.. _profilemode:

==================================================
:mod:`profilemode` -- profiling PyTensor functions
==================================================


.. module:: pytensor.compile.profilemode
   :platform: Unix, Windows
   :synopsis: profiling PyTensor functions with ProfileMode
.. moduleauthor:: LISA

Guide
=====

.. note::

    ProfileMode is removed. Use :attr:`config.profile` instead.
