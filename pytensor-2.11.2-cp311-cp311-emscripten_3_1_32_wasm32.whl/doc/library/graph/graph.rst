.. _libdoc_graph_graph:

================================================
:mod:`graph` -- Interface for the PyTensor graph
================================================

---------
Reference
---------

.. automodule:: pytensor.graph.basic
   :platform: Unix, Windows
   :synopsis: Interface for types of symbolic variables
   :members:
.. moduleauthor:: LISA
