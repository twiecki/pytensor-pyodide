
.. _libdoc_graph:

================================================
:mod:`graph` -- Theano Internals [doc TODO]
================================================

.. module:: graph
   :platform: Unix, Windows
   :synopsis: Theano Internals
.. moduleauthor:: LISA

.. toctree::
    :maxdepth: 1

    graph
    fgraph
    features
    op
    type
    utils
