
.. _libdoc_graph_op:

==============================================================
:mod:`graph` -- Objects and functions for computational graphs
==============================================================

.. automodule:: pytensor.graph.op
   :platform: Unix, Windows
   :synopsis: Interface for types of symbolic variables
   :members:
.. moduleauthor:: LISA
