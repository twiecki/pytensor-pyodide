..  ../../../../pytensor/sandbox/linalg/ops.py
..  ../../../../pytensor/sandbox/linalg

.. _libdoc_sandbox_linalg:

===================================================================
:mod:`sandbox.linalg` --  Linear Algebra Ops
===================================================================

.. module:: sandbox.linalg
   :platform: Unix, Windows
   :synopsis: Linear Algebra Ops
.. moduleauthor:: LISA

API
===

.. automodule:: pytensor.sandbox.linalg.ops
    :members:
