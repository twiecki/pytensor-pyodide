
==========
Functional
==========

Want to know about PyTensor's `function design
<http://groups.google.com/group/theano-dev/browse_thread/thread/fd4c6947d8a20510>`?
