from pytensor.sandbox.linalg.ops import spectral_radius_bound
