# TODO: This is for backward-compatibility; remove when reasonable.
from pytensor.tensor.random.rewriting.basic import *


# isort: off

# Register JAX specializations
import pytensor.tensor.random.rewriting.jax

# isort: on
